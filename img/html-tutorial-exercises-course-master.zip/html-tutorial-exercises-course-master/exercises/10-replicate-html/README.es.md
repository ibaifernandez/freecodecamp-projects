# `10` Replicate HTML

Esta es una imagen de un documento HTML que realizamos. 

![demo](../../.learn/assets/10-replicate-html.png?raw=true)

## 📝 Instrucciones:

1. Por favor, escribe el código HTML necesario para replicar la imagen anterior.

## 💡 Pistas:

+ Debes utilizar las etiquetas `<h1>`, `<h2>`, `<ul>`, `<ol>`, `<li>`, `<p>`.

+ Aquí está el texto para que no tengas que escribirlo todo:

```md
The learning essay

3 signals you know you are learning

Here are the 3 most common signs that shows you are learning

+ You are able to complete the exercises by yourself.
+ You understand what the teacher is talking about.
+ You are able to have conversations about the topic.

3 reasons you love what you are learning

+ Time passes fast.
+ You are anxious to finish this exercise and start the next one.
+ Is 12am and you don't want to go to sleep.
```